import math

def ecuacion(a,b,c):
    discriminante = b**2 - 4*a*c

    if discriminante > 0:
        x1 = (-b + math.sqrt(discriminante))/ (2*a)
        x2 = (-b - math.sqrt(discriminante))/ (2*a)
        return(x1, x2)
    elif discriminante == 0:
        x = (-b + math.sqrt(discriminante))/ (2*a)
        return x
    else: 
        return("no hay soulcion")

a = float(input("Ingrese el valor de a: "))
b = float(input("Ingrese el valor de b: "))
c = float(input("Ingrese el valor de c: "))

resultado = ecuacion(a,b,c)
print(" El resultado es: ", resultado)