from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

def test_caso1(driver):
    driver.get('https://www.saucedemo.com/')
    usuario = driver.find_element(By.ID, 'user-name')
    pass1 = driver.find_element(By.ID, 'password')
    btlogin = driver.find_element(By.ID, 'login-button')

    usuario.send_keys('standard_user')
    pass1.send_keys('secret_sauce')
    btlogin.click()

    dropdwn = driver.find_element(By.CLASS_NAME, 'product_sort_container')
    orden = Select(dropdwn)
    orden.select_by_visible_text('Price (low to high)')

    precios = driver.find_elements(By.CLASS_NAME, 'inventory_item_price')
    lista_precios= []
    for precio in precios:
        numero = float(precio.text.replace('$',''))
        lista_precios.append(numero)

    assert lista_precios == sorted(lista_precios)    