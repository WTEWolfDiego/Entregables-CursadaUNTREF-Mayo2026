from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

def test_caso3(driver):
    driver.get('https://www.saucedemo.com/')
    usuario = driver.find_element(By.ID, 'user-name')
    pass1 = driver.find_element(By.ID, 'password')
    btlogin = driver.find_element(By.ID, 'login-button')

    usuario.send_keys('standard_user')
    pass1.send_keys('secret_sauce')
    btlogin.click()

    elemento1 = driver.find_element(By.ID, 'add-to-cart-sauce-labs-backpack')
    iconocarrito = driver.find_element(By.CLASS_NAME, 'shopping_cart_link')
    elemento1.click()
    iconocarrito.click()

    quitarelemento = driver.find_element(By.ID, 'remove-sauce-labs-backpack')
    quitarelemento.click()
    elementoscarrito = driver.find_elements(By.CLASS_NAME, 'cart_item')
    assert len(elementoscarrito) == 0
    bshopping = driver.find_element(By.ID, 'continue-shopping')
    bshopping.click()

    elemento1 = driver.find_element(By.ID, 'add-to-cart-sauce-labs-backpack')
    elemento2 = driver.find_element(By.ID, 'add-to-cart-sauce-labs-bike-light')
    iconocarrito = driver.find_element(By.CLASS_NAME, 'shopping_cart_link')
    elemento1.click()
    elemento2.click()
    iconocarrito.click()

    elementoscarrito = driver.find_elements(By.CLASS_NAME, 'cart_item')
    assert len(elementoscarrito) == 2
    btcheckout = driver.find_element(By.ID, 'checkout')
    btcheckout.click()

    fname = driver.find_element(By.ID, 'first-name')
    lname = driver.find_element(By.ID, 'last-name')
    zipp = driver.find_element(By.ID, 'postal-code')
    btcontinue = driver.find_element(By.ID, 'continue')
    fname.send_keys('Gabis')
    lname.send_keys('Vega')
    zipp.send_keys('4500')
    btcontinue.click()
    time.sleep(3)

    btfinish = driver.find_element(By.ID, 'finish')
    btfinish.click()

    exito = driver.find_element(By.XPATH, "//h2[@data-test='complete-header']")
    assert exito.text == "Thank you for your order!"

