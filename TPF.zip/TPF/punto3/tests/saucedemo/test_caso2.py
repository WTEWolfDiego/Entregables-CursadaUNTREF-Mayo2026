from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

def test_caso2(driver):
    driver.get('https://www.saucedemo.com/')
    usuario = driver.find_element(By.ID, 'user-name')
    pass1 = driver.find_element(By.ID, 'password')
    btlogin = driver.find_element(By.ID, 'login-button')

    usuario.send_keys('standard_user')
    pass1.send_keys('secret_sauce')
    btlogin.click()


    carritos = driver.find_elements(By.CLASS_NAME, 'btn_inventory') 
    for addc in carritos:
        addc.click()

    iconocarrito = driver.find_element(By.CLASS_NAME, 'shopping_cart_link')
    iconocarrito.click()

    carritos2 = driver.find_elements(By.CLASS_NAME, 'cart_item')

    assert len(carritos) == len(carritos2)

    btcheckout = driver.find_element(By.ID, 'checkout')
    btcheckout.click()

    fname = driver.find_element(By.ID, 'first-name')
    lname = driver.find_element(By.ID, 'last-name')
    btcontinue = driver.find_element(By.ID, 'continue')
    fname.send_keys('Gabis')
    btcontinue.click()
    time.sleep(3)

    errorName = driver.find_element(By.XPATH, "//h3[@data-test='error']")
    assert errorName.text == "Error: Last Name is required"

    lname.send_keys('Vega')
    btcontinue.click()
    time.sleep(3)
    errorPC = driver.find_element(By.XPATH, "//h3[@data-test='error']")
    assert errorPC.text == "Error: Postal Code is required"