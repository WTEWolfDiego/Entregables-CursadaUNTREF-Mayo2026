import requests

def test_caso3():
    url = "https://pokeapi.co/api/v2"

    response = requests.get(url + "/pokemon/pikachu/")
    data = response.json()
    print(data)

    assert (data['base_experience']) > 10 and (data['base_experience']) < 1000
    assert (data['types'][0]['type']['name']) == "electric"
