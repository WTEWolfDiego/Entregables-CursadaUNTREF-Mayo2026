import requests

def test_caso2():
    url = "https://pokeapi.co/api/v2"

    response = requests.get(url + "/berry/2")
    data = response.json()
    print(data)

    assert (data['firmness']['name']) == "super-hard"
    assert (data['size']) > 20
    assert (data['soil_dryness']) == 15
    