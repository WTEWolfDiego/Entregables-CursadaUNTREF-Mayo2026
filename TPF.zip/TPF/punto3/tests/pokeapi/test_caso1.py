import requests

def test_caso1():
    url = "https://pokeapi.co/api/v2"

    response = requests.get(url + "/berry/1")
    data = response.json()
    print(data)

    assert (data['size']) == 20
    assert (data['soil_dryness']) == 15
    assert (data['firmness']['name']) == "soft"


