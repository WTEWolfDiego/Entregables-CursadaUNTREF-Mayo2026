def es_primo(numero):
   if numero<= 1:
      return False 
   
   if numero ==2:
      return True
   
   for i in range(2, numero):
      if numero % i ==0:
         return False
      
   return True


numero = int(input("Ingresa un número: "))
resultado = es_primo(numero)
print("El número es primo?", resultado)

