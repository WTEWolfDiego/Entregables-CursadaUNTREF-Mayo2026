import requests

def test_pokeapi_caso3():
    response = requests.get("https://pokeapi.co/api/v2/pokemon/pikachu/")
    
    assert response.status_code == 200
    data = response.json()

    assert data["base_experience"] > 10
    assert data["base_experience"] < 1000
    assert data["types"][0]["type"]["name"] == "electric"

    print("Caso 3 OK")