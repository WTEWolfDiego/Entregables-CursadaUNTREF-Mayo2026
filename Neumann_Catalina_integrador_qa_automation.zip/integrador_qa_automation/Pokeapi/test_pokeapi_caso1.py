import requests
def test_pokeapi_caso1():
    response = requests.get("https://pokeapi.co/api/v2/berry/1")

    assert response.status_code == 200

    data = response.json()

    assert data["size"] == 20
    assert data["soil_dryness"] == 15
    assert data["firmness"]["name"] == "soft"

    print("Caso 1 OK")