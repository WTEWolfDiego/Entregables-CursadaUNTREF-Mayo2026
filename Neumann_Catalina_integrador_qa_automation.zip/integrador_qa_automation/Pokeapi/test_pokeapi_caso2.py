import requests

def test_pokeapi_caso2():
    response = requests.get("https://pokeapi.co/api/v2/berry/2")
    assert response.status_code == 200

    data = response.json()
    assert data["firmness"]["name"] == "super-hard"

    berry1 = requests.get(
        "https://pokeapi.co/api/v2/berry/1"
    ).json()

    assert data["size"] > berry1["size"]
    assert data["soil_dryness"] == berry1["soil_dryness"]

    print("Caso 2 OK")