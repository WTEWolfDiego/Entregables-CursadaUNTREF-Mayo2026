import math

def calcular_raices(a, b, c):

    discriminante = b**2 - 4*a*c

    if discriminante < 0:
        return "No tiene raíces reales"
    x1 = (-b + math.sqrt(discriminante)) / (2*a)
    x2 = (-b - math.sqrt(discriminante)) / (2*a)

    return x1, x2
print(calcular_raices(1, -5, 6))