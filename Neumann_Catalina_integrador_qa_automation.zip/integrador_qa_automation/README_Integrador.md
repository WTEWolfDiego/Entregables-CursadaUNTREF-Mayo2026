#Integrador QA Automation Módulo 3
Proyecto realizado utilizando Python, Selenium, Requests y Pytest.

#Casos Selenium
- Caso 1: Ordenamiento de productos por precio.
- Caso 2: Validación de errores en checkout.
- Caso 3: Flujo completo de compra.
#Casos PokeAPI
- Caso 1: Validación de Berry 1.
- Caso 2: Comparación de berries.
- Caso 3: Validación de Pikachu.

#Ejecución

Ejecutar todos los tests:

py -m pytest -v

Generar reporte HTML:

py -m pytest -v --html=reporte.html --self-contained-html

## Resultado

6 casos ejecutados.
6 casos aprobados.