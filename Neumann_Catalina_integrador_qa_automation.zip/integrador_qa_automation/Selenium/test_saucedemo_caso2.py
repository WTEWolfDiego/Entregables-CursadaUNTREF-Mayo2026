from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
import time


def test_saucedemo_caso2():

    options = Options()
    options.add_argument("--guest")

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 10)

    driver.get("https://www.saucedemo.com/")

    driver.find_element(By.ID, "user-name").send_keys("standard_user")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    driver.find_element(By.ID, "login-button").click()

    
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "inventory_item")) > 0)

    botones_carrito = driver.find_elements(By.CLASS_NAME, "btn_inventory")

    for boton in botones_carrito:
        boton.click()

 
    driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()

    #verificar que esten los 6 productos
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "cart_item")) == 6)

    productos_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")

    assert len(productos_carrito) == 6

    #checkout
    wait.until(lambda d: len(d.find_elements(By.ID, "checkout")) > 0)
    driver.find_element(By.ID, "checkout").click()

    #formulario de checkout
    wait.until(lambda d: len(d.find_elements(By.ID, "first-name")) > 0)

    #nombre y continuar
    driver.find_element(By.ID, "first-name").send_keys("Catalina")
    driver.find_element(By.ID, "continue").click()

    #error apellido
    wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "[data-test='error']")) > 0)
    mensaje_error = driver.find_element(By.CSS_SELECTOR, "[data-test='error']")

    assert mensaje_error.text == "Error: Last Name is required"

    #apellido
    driver.find_element(By.ID, "last-name").send_keys("Neumann")
    driver.find_element(By.ID, "continue").click()

    #error codigo postal
    wait.until(lambda d: len(d.find_elements(By.CSS_SELECTOR, "[data-test='error']")) > 0)
    mensaje_error = driver.find_element(By.CSS_SELECTOR, "[data-test='error']")

    assert mensaje_error.text == "Error: Postal Code is required"

    print("Caso 2 OK")

    driver.quit()