from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options


def test_saucedemo_caso3():

    options = Options()
    options.add_argument("--guest")

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 10)

    driver.get("https://www.saucedemo.com/")

    # Login
    driver.find_element(By.ID, "user-name").send_keys("standard_user")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    driver.find_element(By.ID, "login-button").click()

    # Esperar a que carguen los productos
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "inventory_item")) > 0)

    # Agregar un elemento
    botones_carrito = driver.find_elements(By.CLASS_NAME, "btn_inventory")
    botones_carrito[0].click()

    # Ir al carrito
    driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()

    # Remover el articulo
    wait.until(lambda d: len(d.find_elements(By.ID, "remove-sauce-labs-backpack")) > 0)
    driver.find_element(By.ID, "remove-sauce-labs-backpack").click()

    # Esperar a que el carrito quede vacio y verificar
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "cart_item")) == 0)

    productos_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")

    assert len(productos_carrito) == 0

    # Continue Shopping
    driver.find_element(By.ID, "continue-shopping").click()

    # Agregar 2 elementos
    wait.until(lambda d: len(d.find_elements(By.ID, "add-to-cart-sauce-labs-backpack")) > 0)
    driver.find_element(By.ID, "add-to-cart-sauce-labs-backpack").click()
    driver.find_element(By.ID, "add-to-cart-sauce-labs-bike-light").click()

    # Ir al carrito
    driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()

    # Esperar y verificar que existan los elementos
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "inventory_item_name")) == 2)

    productos = driver.find_elements(By.CLASS_NAME, "inventory_item_name")

    nombres_productos = []

    for producto in productos:
        nombres_productos.append(producto.text)

    assert "Sauce Labs Backpack" in nombres_productos
    assert "Sauce Labs Bike Light" in nombres_productos

    # Checkout
    driver.find_element(By.ID, "checkout").click()

    # Esperar el formulario e ingresar datos
    wait.until(lambda d: len(d.find_elements(By.ID, "first-name")) > 0)
    driver.find_element(By.ID, "first-name").send_keys("Catalina")
    driver.find_element(By.ID, "last-name").send_keys("Neumann")
    driver.find_element(By.ID, "postal-code").send_keys("5300")
    driver.find_element(By.ID, "continue").click()

    # Finalizar compra
    wait.until(lambda d: len(d.find_elements(By.ID, "finish")) > 0)
    driver.find_element(By.ID, "finish").click()

    # Verificar que la compra fue realizada
    wait.until(lambda d: len(d.find_elements(By.CLASS_NAME, "complete-header")) > 0)
    mensaje = driver.find_element(By.CLASS_NAME, "complete-header")

    assert mensaje.text == "Thank you for your order!"

    print("Caso 3 OK")

    driver.quit()