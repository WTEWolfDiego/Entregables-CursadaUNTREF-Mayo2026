from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

def test_saucedemo_caso1():

    driver = webdriver.Chrome()

    driver.get("https://www.saucedemo.com/")

    driver.find_element(By.ID, "user-name").send_keys("standard_user")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    driver.find_element(By.ID, "login-button").click()

    
    filtro_ordenamiento = Select(
        driver.find_element(By.CLASS_NAME, "product_sort_container")
)

    filtro_ordenamiento.select_by_visible_text("Price (low to high)")

    # obtener precios
    precios = driver.find_elements(By.CLASS_NAME, "inventory_item_price")

    lista_precios = []

    for precio in precios:
        valor = float(precio.text.replace("$", ""))
        lista_precios.append(valor)

    #orden
    assert lista_precios == sorted(lista_precios)

    time.sleep(2)

    driver.quit()