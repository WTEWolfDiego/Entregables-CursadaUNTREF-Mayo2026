import math

####################################### EJERCICIO 1 ###############################################################

print("EJERCICIO 1")
print()

def nro_primo(nro): #Nro igual o menor a 1 no es primo. Devuelve False.
    if nro <= 1:
        return False
    
    for i in range(2, nro): #Verifica si es divisible por los nros dentro del rango. Si no hay resto, devuelve False.
        if nro % i == 0:
            return False
    
    return True #Es nro primo, devuelve True.

input_nro = int(input("Por favor ingrese un número: "))
if nro_primo(input_nro):
    print(f"El número {input_nro} es un número primo.")
else:
    print(f"El número {input_nro} no es un número primo.")

print()
print("Programa finalizado")
print()
####################################### EJERCICIO 2 ###############################################################

print("EJERCICIO 2")
print()

def ecuacion_cuadratica(a,b,c):
    #Calculo lo que se encuentra dentro de la raiz (discriminante).
    discriminante = b**2 - 4*a*c
    #Evalúo las posibles soluciones dependiendo del valor del discriminante.
    if discriminante > 0:
        #Solución usando el signo +.
        raiz1 = (-b + math.sqrt(discriminante)) / (2*a)
        #Solución usando el signo -.
        raiz2 = (-b - math.sqrt(discriminante)) / (2*a)
        #Devuelve ambas soluciones.
        return raiz1, raiz2
    elif discriminante == 0:
        #Solución única usando el signo + o - (ambas son iguales).
        raiz = -b / (2*a)
        return raiz
    else:
        return f"Al ser el discriminante negativo, no hay solución."

input_1 = float(input("Ingrese el valor de a: "))
input_2 = float(input("Ingrese el valor de b: "))
input_3 = float(input("Ingrese el valor de c: "))

result = ecuacion_cuadratica(input_1, input_2, input_3)
print(result)
print()
print("Programa finalizado")
print()
