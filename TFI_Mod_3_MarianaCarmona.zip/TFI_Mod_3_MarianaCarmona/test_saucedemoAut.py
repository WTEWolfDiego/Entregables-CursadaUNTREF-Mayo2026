import pytest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


################################# FIXTURE ##########################################################

@pytest.fixture 
def driver():                   #SETUP. Abre el navegador antes de cada test.
    driver = webdriver.Chrome() #Abre el navegador Chrome.
    driver.maximize_window()    #Maximiza la ventana.

    yield driver                #Se inician los tests.
    driver.quit()               #TearDown. Cierra el navegador luego de la ejecución de los tests.

@pytest.fixture                 #Devuelve la URL base de la página web.
def base_url():                 
    return "https://www.saucedemo.com/"    

################################# PAGE OBJECT #########################################################

class SauceDemoPage:   #Clase que representa la página, con sus métodos para interactuar con ella.
    def __init__(self, driver, base_url): #Constructor de la clase, que recibe parámetros.
        self.driver = driver
        self.base_url = base_url

    def login(self,username, password):#Método para iniciar sesión con credenciales válidas.
        self.driver.get(self.base_url) #Navego a la página e inicio sesión.
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="username"]').send_keys(username)
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="password"]').send_keys(password)
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="login-button"]').click()

    def order_by_price(self): #Ubico el menú desplegable y selecciono por precio menor a mayor.
        dropdown_list = Select(self.driver.find_element(By.CSS_SELECTOR, '[data-test="product-sort-container"]'))
        dropdown_list.select_by_value("lohi")

    def get_prices_list(self): #Identifico los items con sus precios en pantalla y los transformo en Float.
        price_items = self.driver.find_elements(By.CSS_SELECTOR, '[data-test="inventory-item-price"]')
        new_list = []
        for item in price_items:
            item_number = float(item.text.replace("$",""))
            new_list.append(item_number)
        return new_list    

    def add_all_items_to_cart(self): #Agrego todos los productos al carrito.
        while True:                  #Mientras haya botones de "Add to cart" en la pantalla.
            buttons = self.driver.find_elements(By.CLASS_NAME, "btn_inventory")
            btn_add = [b for b in buttons if "btn_primary" in b.get_attribute("class")] #Filtro que el botón sea de agregar.
            
            if len(btn_add) > 0:
                btn_add[0].click() #Click al primer botón real en pantalla.
                time.sleep(0.4)
            else:
                break #Rompe el bucle si ya no quedan botones de agregar (los 6 dicen Remove).

    def go_to_cart(self): #Método para hacer click sobre el icóno de carrito de compras.
        time.sleep(2)
        self.driver.find_element(By.CSS_SELECTOR,'[data-test="shopping-cart-link"]').click()  
        time.sleep(0.3)      

    def all_items_in_cart(self): #Método para obtener los items en el carrito.
        badge = self.driver.find_element(By.CSS_SELECTOR, '[data-test="shopping-cart-badge"]')
        return int(badge.text)
    
    def go_to_checkout(self): #Método para hacer click sobre el botón de Checkout.
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="checkout"]').click()
        
    def checkout_form(self, firstname, lastname, postalcode): #Método para completar el formulario del Checkout.
        first_name = self.driver.find_element(By.CSS_SELECTOR, '[data-test="firstName"]')
        first_name.clear()
        first_name.send_keys(firstname)
        last_name = self.driver.find_element(By.CSS_SELECTOR, '[data-test="lastName"]')
        last_name.clear()
        last_name.send_keys(lastname)
        postal_code = self.driver.find_element(By.CSS_SELECTOR, '[data-test="postalCode"]')
        postal_code.clear()
        postal_code.send_keys(postalcode)
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="continue"]').click()

    def add_items_to_cart(self, quantity): #Método para agregar items al carrito.
        products = self.driver.find_elements(By.XPATH, '//button[text()="Add to cart"]') 
        for i in range(quantity):
            products[i].click()
            time.sleep(1)

    def remove_item_from_cart(self): #Método creado para eliminar un item del carrito.
        self.driver.find_element(By.CSS_SELECTOR, '[data-test^="remove-"]').click()       

    def check_empty_cart(self): #Método para verificar que el carrito se encuentra vacío.
        badge = self.driver.find_elements(By.CSS_SELECTOR, '[data-test="shopping-cart-badge"]')
        return len(badge)  == 0

    def continue_shopping(self): #Método para hacer click en el botón de Continue Shopping.
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="continue-shopping"]').click()

    def finish_shopping(self, firstname, lastname, postalcode): #Método para hacer click en Finalizar compra usando el método de form.
        self.checkout_form(firstname, lastname, postalcode)
        self.driver.find_element(By.CSS_SELECTOR, '[data-test="finish"]').click()


############################################ TEST SUITE ######################################################

#------------------------------------------- TEST 1 ---------------------------------------------------------#

def test_login_order_items(driver, base_url): # Test de inicio de sesión y filtrado de items.
    pageSauce = SauceDemoPage(driver, base_url) #Navego a la página.
    pageSauce.login("standard_user", "secret_sauce") #Inicio sesión.

    assert "inventory.html" in driver.current_url, f"Login ha fallado y no se ha podido acceder a la página principal."
    assert driver.title == "Swag Labs", f"El texto del titulo de la página no es el esperado."
    
    pageSauce.order_by_price() 
    
    price_items = pageSauce.get_prices_list() 
    assert price_items == sorted(price_items), f"Los elementos no estan ordenados por precio de menor a mayor."
    assert all(isinstance(item, float) for item in price_items), f"Hay items que no son  tipo float."

#-------------------------------------------- TEST 2 ---------------------------------------------------------#    

def test_login_cart_checkout(driver, base_url): #Test de inicio de sesión y agregar items al carrito y realizar checkout.
    pageSauce =SauceDemoPage(driver, base_url)
    pageSauce.login("standard_user", "secret_sauce")
    pageSauce.add_all_items_to_cart()
    
    items_in_cart = pageSauce.all_items_in_cart()
    assert items_in_cart == 6, f"No se ha encontrado el número esperado de productos en el carrito."

    pageSauce.go_to_cart()

    assert "/cart.html" in driver.current_url, f"No se pudo ingresar a la sección del carrito de compras."

    pageSauce.go_to_checkout()

    assert "/checkout-step-one.html" in driver.current_url, f"No se pudo acceder a la primera sección del checkout."

    pageSauce.checkout_form("Emma", "", "")
    message_error_lastname = driver.find_element(By.CSS_SELECTOR, '[data-test="error"]')
    assert message_error_lastname.text == "Error: Last Name is required", f"No se muestra ningun mensaje de error."

    pageSauce.checkout_form("Emma", "Suarez", "")
    message_error_postalcode = driver.find_element(By.CSS_SELECTOR, '[data-test="error"]')
    assert message_error_postalcode.text == "Error: Postal Code is required", f"No se visualiza ningun mensaje de error."

#------------------------------------------- TEST 3 ---------------------------------------------------------#

def test_login_checkout_flow(driver, base_url): #Test de flujo completo de compra.
    pageSauce = SauceDemoPage(driver, base_url)
    pageSauce.login("standard_user", "secret_sauce")
    pageSauce.add_items_to_cart(1)
    pageSauce.go_to_cart()
    pageSauce.remove_item_from_cart()
    time.sleep(0.3)
    assert pageSauce.check_empty_cart(), f"El carrito de compras no se encuentra vacio."
    
    pageSauce.continue_shopping()
    assert "inventory.html" in driver.current_url, f"Login ha fallado y no se ha podido acceder a la página principal."
    pageSauce.add_items_to_cart(2)
    pageSauce.go_to_cart()
    items_in_cart = pageSauce.all_items_in_cart()
    assert items_in_cart == 2, f"No se han encontrado productos dentro del carrito."
    pageSauce.go_to_checkout()
    assert "/checkout-step-one.html" in driver.current_url, f"No se logró ingresar a la sección de checkout."

    pageSauce.finish_shopping("Emma", "Suarez", "5800")

    assert "checkout-complete.html" in driver.current_url, f"No se pudo acceder a la página de compra finalizada."

    img_check = driver.find_element(By.CSS_SELECTOR, '[data-test="pony-express"]')
    assert img_check.is_displayed(), f"No se visualiza el ícono de check verde de compra exitosa."

    success_message = driver.find_element(By.CSS_SELECTOR,'[data-test="complete-header"]')
    assert "Thank you for your order!" in success_message.text, f"No se visualiza ningun título de compra exitosa."

    success_delivery_message = driver.find_element(By.CSS_SELECTOR, '[data-test="complete-text"]')
    delivery_text ="Your order has been dispatched, and will arrive just as fast as the pony can get there!"
    assert delivery_text in success_delivery_message.text, f"No se muestra ningún mensaje de validación de compra enviada con éxito."
    
    