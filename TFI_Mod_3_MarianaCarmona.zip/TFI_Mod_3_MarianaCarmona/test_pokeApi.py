import pytest
import requests

@pytest.fixture #Fixture para declarar la URL raíz de la API.
def base_url():
    return "https://pokeapi.co/api/v2"


"""
Profe: pensé en usar esta instrucción pero me pareció que me iba a terminar complicando algo que era más simple.
#@pytest.mark.parametrize("endpoint", ["berry/1", "berry/2", "pokemon/pikachu"])
"""

############################# TEST CASE 1 ##############################################

#Creación de URL específica y petición GET.
def test_case_1(base_url):
    url_pokeapi = f"{base_url}/berry/1"
    response1 = requests.get(url_pokeapi)

    #Valido que el código de respuesta sea exitoso. No lo pide la consigna, pero es buena práctica.
    assert response1.status_code == 200, f"Se esperaba un status code 200, pero se obtuvo {response1.status_code}."

    #Obtengo el cuerpo de la respuesta en formato JSON.
    json_test_1 = response1.json()

    #Verifico que los datos contenidos en 'size', 'soil_dryness' y 'name' sean los esperados.
    assert json_test_1["size"] == 20, f"El contenido de 'size' no coincide con el resultado obtenido."
    assert json_test_1["soil_dryness"] == 15, f"El contenido de 'soil_dryness' no coincide con el resultado obtenido."
    assert json_test_1["firmness"]["name"] == "soft", f"El contenido de 'name' dentro de 'firmness' no coincide con el resultado obtenido."

############################# TEST CASE 2 ##############################################

#Obtengo la  URL específica y realizo la petición GET.
def test_case_2(base_url):
    url_pokeapi = f"{base_url}/berry/2"
    response2 = requests.get(url_pokeapi)
    
    #Valido que el código de respuesta sea exitoso.
    assert response2.status_code == 200, f"Se esperaba un status code 200, pero se obtuvo {response2.status_code}."

    #Obtengo el cuerpo de la respuesta en formato JSON.
    json_test_2 = response2.json()

    #Datos del test anterior para realizar comparación.
    size_berry1 = 20
    soil_dryness1 = 15

    #Verifico que el dato contenido en 'name' sea el esperado y que los datos contenidos en 'size' y 'soil_dryness' coincidan con los del test anterior.
    assert json_test_2["firmness"]["name"] == "super-hard",f"El contenido de 'name' dentro de 'firmness' no coincide con el resultado obtenido."
    assert json_test_2["size"] > size_berry1, f"El contenido de 'size' no es mayor a {size_berry1}."
    assert json_test_2["soil_dryness"] == soil_dryness1, f"El contenido de 'soil_dryness' no coincide con el resultado obtenido."

############################# TEST CASE 3 ##############################################

#Obtengo la  URL específica y realizo la petición GET.
def test_case_3(base_url):
    url_pokeapi = f"{base_url}/pokemon/pikachu/"
    response3 = requests.get(url_pokeapi)

    #Valido el estado de la respuesta.
    assert response3.status_code == 200, f"Se esperaba un status code 200, pero se obtuvo {response3.status_code}."

    #Obtengo el cuerpo de la respuesta en formato JSON.
    json_test_3 = response3.json()

    #Verifico que 'experiencia base' sea mayor a 10 y menor a 1000.
    base_exp =json_test_3["base_experience"]
    assert 10< base_exp < 1000, f"Se esperaba un resultado sobre experiencia base entre 10 y 1000."

    #Verifico que su tipo sea el esperado.
    poke_type = [t['type']['name'] for t in json_test_3['types']]
    assert "electric" in poke_type, f"El tipo obtenido no corresponde al tipo esperado."
    
