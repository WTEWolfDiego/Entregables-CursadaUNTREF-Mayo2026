it('Caso 3: Validar experiencia base y tipo de Pikachu', () => {
    // Envía GET al endpoint de Pikachu
    cy.request('GET', 'https://pokeapi.co/api/v2/pokemon/pikachu/').then((response) => {
        
        // Valida de estado de la petición
        expect(response.status).to.eq(200);

        // 1. Verifica que su experiencia base es mayor a 10 y menor a 1000
        const baseExp = response.body.base_experience;
        expect(baseExp).to.be.above(10);
        expect(baseExp).to.be.below(1000);

        // 2. Verifica que su tipo es "electric"
        const tiposPokemon = response.body.types.map(t => t.type.name);
        
        // Validamos que la lista de tipos incluya 'electric'
        expect(tiposPokemon).to.include('electric');
    });
});