describe('SauceDemo - Caso 3: Ciclo de Compra Completo', () => {

    beforeEach(() => {
        // Aislamiento de pruebas limpiando el estado
        cy.clearCookies();
        cy.clearLocalStorage();
        cy.visit('https://www.saucedemo.com/');
    });

    it('Debería operar el carrito (agregar/remover), reabastecer y finalizar la compra con éxito', () => {
        // === 1. LOG-IN ===
        cy.get('[data-test="username"]').type('standard_user');
        cy.get('[data-test="password"]').type('secret_sauce');
        cy.get('[data-test="login-button"]').click();

        // === 2. AGREGAR UN ELEMENTO AL CARRITO ===
        // Seleccionamos solo el primer botón de "Add to cart" que encuentre
        cy.get('button[data-test^="add-to-cart"]').eq(0).click();

        // === 3. IR AL CARRITO Y REMOVER EL ARTÍCULO ===
        cy.get('[data-test="shopping-cart-link"]').click();
        
        // Clickeamos el botón de remover (su data-test empieza con "remove-")
        cy.get('button[data-test^="remove-"]').click();

        // === 4. VERIFICAR QUE EL SITIO NO TIENE ARTÍCULOS AGREGADOS ===
        // Validamos que el contenedor del ítem del carrito ya no exista en el DOM
        cy.get('.cart_item').should('not.exist');
        cy.get('.shopping_cart_badge').should('not.exist');

        // === 5. IR A "CONTINUE SHOPPING" Y AGREGAR 2 ELEMENTOS ===
        cy.get('[data-test="continue-shopping"]').click();
        cy.url().should('include', '/inventory.html');

        // Agregamos los primeros dos productos de la lista uno por uno
        cy.get('button[data-test^="add-to-cart"]').eq(0).click();
        cy.get('button[data-test^="add-to-cart"]').eq(1).click(); // .eq(1) es el segundo elemento (índice 1)

        // === 6. IR AL CARRITO Y VERIFICAR QUE LOS ELEMENTOS EXISTAN ===
        cy.get('[data-test="shopping-cart-link"]').click();
        cy.get('.cart_item').should('have.length', 2);

        // === 7. HACER EL CHECKOUT ===
        cy.get('[data-test="checkout"]').click();
        
        // Completa los datos de manera limpia y sin errores
        cy.get('[data-test="firstName"]').type('Juan');
        cy.get('[data-test="lastName"]').type('Pérez');
        cy.get('[data-test="postalCode"]').type('1234');
        cy.get('[data-test="continue"]').click();

        // Redirección a la pantalla de revisión (Overview)
        cy.url().should('include', '/checkout-step-two.html');

        // === 8. FINALIZAR LA COMPRA ===
        cy.get('[data-test="finish"]').click();

        // === 9. VERIFICAR QUE LA COMPRA FUE REALIZADA ===
        cy.url().should('include', '/checkout-complete.html');
        
        // Valida el mensaje de éxito clásico de SauceDemo
        cy.get('.complete-header')
            .should('be.visible')
            .and('have.text', 'Thank you for your order!');
    });
});