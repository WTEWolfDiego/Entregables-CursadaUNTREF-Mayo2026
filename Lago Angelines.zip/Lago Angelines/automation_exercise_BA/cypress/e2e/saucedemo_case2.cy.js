describe('SauceDemo - Caso 2: Carrito y Errores de Checkout', () => {
    
    beforeEach(() => {
        // Limpieza absoluta para evitar redirecciones automáticas al inventario
        cy.clearCookies();
        cy.clearLocalStorage();
        cy.visit('https://www.saucedemo.com/');
    });

    it('Debería agregar todos los productos, ir al checkout y validar los campos requeridos', () => {
        // 1. Proceso de autenticación
        cy.get('[data-test="username"]').type('standard_user');
        cy.get('[data-test="password"]').type('secret_sauce');
        cy.get('[data-test="login-button"]').click();

     // === 2. INCORPORA AL CARRITO TODOS LOS ELEMENTOS ===
    cy.get('button[data-test^="add-to-cart"]').then(($botones) => {
        const cantidadEsperada = $botones.length; // Guardamos el número exacto aquí dentro (ej: 6)

        // Clickeamos uno por uno 
        cy.get('button[data-test^="add-to-cart"]').each(($el) => {
            cy.wrap($el).click();
        });

        // === 3. IR AL CARRITO Y VERIFICAR ELEMENTOS ===
        // Metemos la navegación y la validación ACÁ para asegurarnos de que 
        // 'cantidadEsperada' no valga cero.
        cy.get('[data-test="shopping-cart-link"]').click();
        cy.url().should('include', '/cart.html');

        //  Cypress sabe buscar el número real (6) y no 0
        cy.get('.cart_item').should('have.length', cantidadEsperada);
    });
    
    // A partir de acá, el código del paso 4 (Ir al checkout) es lo mismo
    cy.get('[data-test="checkout"]').click();
    
        // 4. Ir al formulario de Checkout
        cy.get('[data-test="continue"]').click();

        // 5. Valida error de Apellido (Last Name) ingresando solo el Nombre
        cy.get('[data-test="firstName"]').type('Juan');
        cy.get('[data-test="continue"]').click();
        cy.get('[data-test="error"]')
            .should('be.visible')
            .and('have.text', 'Error: Last Name is required');

        // 6. Valida error de Código Postal (Postal Code) agregando el Apellido
        cy.get('[data-test="lastName"]').type('Pérez');
        cy.get('[data-test="continue"]').click();
        cy.get('[data-test="error"]')
            .should('be.visible')
            .and('have.text', 'Error: Postal Code is required');
    });
});