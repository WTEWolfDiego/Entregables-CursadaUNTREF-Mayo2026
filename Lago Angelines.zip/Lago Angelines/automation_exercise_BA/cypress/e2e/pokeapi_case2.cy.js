it('Caso 2: Validar Baya 2 y comparar sus datos con la Baya 1', () => {
    // 1. Consulta la Baya 1 para capturar sus valores reales
    cy.request('GET', 'https://pokeapi.co/api/v2/berry/1').then((responseBaya1) => {
        const sizeBaya1 = responseBaya1.body.size;                 // Vale 20
        const soilDrynessBaya1 = responseBaya1.body.soil_dryness;   // Vale 15

        // 2. Metemos la petición de la Baya 2 para tener las variables en el mismo bloque
        cy.request('GET', 'https://pokeapi.co/api/v2/berry/2').then((responseBaya2) => {
            
            // Valida estado de la segunda petición
            expect(responseBaya2.status).to.eq(200);

            //Verifica que en firmness, el name sea super-hard
            expect(responseBaya2.body.firmness.name).to.eq('super-hard');

            // B: Verifica que el size sea mayor al del punto anterior
            expect(responseBaya2.body.size).to.be.above(sizeBaya1);

            //  C: Verifica que el soil_dryness sea igual al del punto anterior
            expect(responseBaya2.body.soil_dryness).to.eq(soilDrynessBaya1);
        });
    });
});