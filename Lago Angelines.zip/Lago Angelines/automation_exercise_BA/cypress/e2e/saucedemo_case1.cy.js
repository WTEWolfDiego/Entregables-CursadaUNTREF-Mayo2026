describe('SauceDemo - Automatización de Inventario', () => {
    
    beforeEach(() => {
        // Visitar el sitio web bajo prueba antes de cada caso
        cy.visit('https://www.saucedemo.com/');
    });

    it('Caso 1: Loguear usuario, ordenar por precio (Low to High) y verificar orden', () => {
        // === 1. PROCESO DE LOG-IN ===
        // Localizamos los elementos usando los atributos HTML
        cy.get('[data-test="username"]').type('standard_user');
        cy.get('[data-test="password"]').type('secret_sauce');
        cy.get('[data-test="login-button"]').click();

        // Verificaa que la URL cambió a la página de inventario
        cy.url().should('include', '/inventory.html');

        // === 2. ORDENAR ELEMENTOS ===
        // Selecciona la opción 'Price (low to high)' usando su valor interno 'lohi'
        cy.get('[data-test="product-sort-container"]').select('lohi');

        // === 3. VERIFICAR QUE LOS ELEMENTOS ESTÉN ORDENADOS ===
        const preciosCapturadosUI = [];

        // Itera por cada uno de los elementos de precio visibles en la interfaz
        cy.get('.inventory_item_price')
            .each(($el) => {
                // Limpia el texto eliminando el "$" y lo transforma en un número flotante
                const precioNumerico = parseFloat($el.text().replace('$', ''));
                preciosCapturadosUI.push(precioNumerico);
            })
            .then(() => {
                // Crea una copia del arreglo original y la ordenamos formalmente de menor a mayor
                const preciosOrdenadosEsperados = [...preciosCapturadosUI].sort((a, b) => a - b);
                
                // Realiza la aserción profunda (deep equal) para verificar que el orden de la UI sea el correcto
                expect(preciosCapturadosUI).to.deep.equal(preciosOrdenadosEsperados);
            });
    });
});