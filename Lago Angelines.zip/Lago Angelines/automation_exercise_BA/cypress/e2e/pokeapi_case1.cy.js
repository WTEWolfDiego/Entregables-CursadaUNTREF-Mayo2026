describe('PokeAPI - Automatización de Pruebas de API', () => {

    it('Caso 1: Validar datos de la Baya (berry/1)', () => {
        // Envía la petición GET al endpoint específico de la baya 1
        cy.request('GET', 'https://pokeapi.co/api/v2/berry/1').then((response) => {
            
            // 1. Valida seguridad: el servicio debe responder con éxito (200)
            expect(response.status).to.eq(200);

            // 2. Verifica que el size sea 20
            expect(response.body.size).to.eq(20);

            // 3. Verifica que el soil_dryness sea 15
            expect(response.body.soil_dryness).to.eq(15);

            // 4. Verifica que en firmness, el name sea soft
            expect(response.body.firmness.name).to.eq('soft');
        });
    });
});