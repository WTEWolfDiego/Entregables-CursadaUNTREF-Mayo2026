import math

def resolver_cuadratica(a, b, c):
    discriminante = b**2 - 4*a*c
    
    if discriminante > 0:
        raiz1 = (-b + math.sqrt(discriminante)) / (2*a)
        raiz2 = (-b - math.sqrt(discriminante)) / (2*a)
        return f"Dos soluciones: {raiz1} y {raiz2}"
    elif discriminante == 0:
        raiz = -b / (2*a)
        return f"Una solución: {raiz}"
    else:
        return "No hay solución real (raíces complejas)."

# Programa principal
a = float(input("Ingrese el valor de a: "))
b = float(input("Ingrese el valor de b: "))
c = float(input("Ingrese el valor de c: "))

print(resolver_cuadratica(a, b, c))