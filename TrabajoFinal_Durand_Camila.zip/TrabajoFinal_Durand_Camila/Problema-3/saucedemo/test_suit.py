from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class TestSauceDemo:

    def test_caso_1(self, driver):
        """
        Caso 1: Login como standard_user, ordenar por precio (low to high)
        y verificar que los elementos estén ordenados correctamente.
        """
        # Navega a la página de inicio de sesión
        driver.get("https://www.saucedemo.com/")

        # Localizar elementos del formulario de login
        username_input = driver.find_element(By.ID, "user-name")
        password_input = driver.find_element(By.ID, "password")
        login_button = driver.find_element(By.ID, "login-button")

        # Ingresar credenciales
        username_input.send_keys("standard_user")
        password_input.send_keys("secret_sauce")
        login_button.click()
        
        # Verificar que el login fue exitoso 
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "inventory_list"))
        )

        # Localizar el dropdown de ordenamiento y seleccionar "Price (low to high)"
        sort_dropdown = driver.find_element(By.CLASS_NAME, "product_sort_container")
        sort_dropdown.click()
        sort_dropdown.find_element(By.XPATH, "//option[@value='lohi']").click()

        # Verificar que los productos estén ordenados por precio de menor a mayor
        prices = driver.find_elements(By.CLASS_NAME, "inventory_item_price")
        price_values = [float(price.text.replace('$', '')) for price in prices]
        assert price_values == sorted(price_values), "Los productos no están ordenados por precio de menor a mayor."

    def test_caso_2(self, driver):
        """
        Caso 2: Login, agregar todos los productos al carrito,
        verificar, y probar validaciones del checkout.
        """
        driver.get("https://www.saucedemo.com/")
    
        # Login
        driver.find_element(By.ID, "user-name").send_keys("standard_user")
        driver.find_element(By.ID, "password").send_keys("secret_sauce")
        driver.find_element(By.ID, "login-button").click()
        
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "inventory_list"))
        )

        # Agregar todos los productos al carrito
        botones_add = driver.find_elements(By.CLASS_NAME, "btn_primary")
        for boton in botones_add:
            boton.click()

        # Ir al carrito
        carrito_icon = driver.find_element(By.CLASS_NAME, "shopping_cart_link")
        carrito_icon.click()
    
        # Esperar que cargue la pagina del carrito
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "cart_list"))
        )

        # Verificar que hay 6 items
        items_en_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")
        cantidad_items_carrito = len(items_en_carrito)
        assert cantidad_items_carrito == 6, f"En el carrito hay {cantidad_items_carrito} items, deberian ser 6"
        
        # Hacer click en Checkout
        checkout_button = driver.find_element(By.ID, "checkout")
        checkout_button.click()
        
        # CORREGIDO: Esperar el formulario de checkout correctamente
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "first-name"))
        )
        
        # Localizar campos del formulario
        first_name_input = driver.find_element(By.ID, "first-name")
        last_name_input = driver.find_element(By.ID, "last-name")
        continue_button = driver.find_element(By.ID, "continue")
        
        # Ingresar solo el nombre
        first_name_input.send_keys("Juan")
        continue_button.click()
        
        # Verificar error de Last Name
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h3[data-test='error']"))
        )
        error_message = driver.find_element(By.CSS_SELECTOR, "h3[data-test='error']")
        assert "Last Name is required" in error_message.text, \
            f"Se esperaba error de apellido, pero se obtuvo: {error_message.text}"
        
        # Ahora ingresamos el apellido
        last_name_input = driver.find_element(By.ID, "last-name")
        last_name_input.send_keys("Perez")
        continue_button.click()
        
        # Verificar error de Postal Code
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h3[data-test='error']"))
        )
        error_message = driver.find_element(By.CSS_SELECTOR, "h3[data-test='error']")
        assert "Postal Code is required" in error_message.text, \
            f"Se esperaba error de codigo postal, pero se obtuvo: {error_message.text}"

    def test_caso_3(self, driver):
        """
        Caso 3: Flujo completo de compra - agregar, remover, volver a agregar,
        checkout y finalizar compra.
        """
        driver.get("https://www.saucedemo.com/")
    
        # Login
        driver.find_element(By.ID, "user-name").send_keys("standard_user")
        driver.find_element(By.ID, "password").send_keys("secret_sauce")
        driver.find_element(By.ID, "login-button").click()
        
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "inventory_list"))
        )

        # Agregar el primer producto al carrito
        primer_boton_add = driver.find_element(By.CSS_SELECTOR, "button.btn_inventory")
        primer_boton_add.click()
        
        # Verificar badge
        carrito_badge = driver.find_element(By.CLASS_NAME, "shopping_cart_badge")
        assert carrito_badge.text == "1", f"Badge muestra {carrito_badge.text}, deberia ser 1"
        
        # Ir al carrito (CORREGIDO: primero ir al carrito, luego esperar)
        driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()
        
        # Esperar que cargue la pagina del carrito
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "cart_list"))
        )

        # Verificar que hay 1 item
        items_en_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")
        cantidad_items_carrito = len(items_en_carrito)
        assert cantidad_items_carrito == 1, f"En el carrito hay {cantidad_items_carrito} items, deberia ser 1"
        
        # Remover el producto
        remove_button = driver.find_element(By.CLASS_NAME, "cart_button")
        remove_button.click()

        # Verificar que el carrito esta vacio
        items_en_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")
        assert len(items_en_carrito) == 0, "El carrito no esta vacio despues de remover el producto."
        
        # Ir a continuar comprando
        boton_continue = driver.find_element(By.ID, "continue-shopping")
        boton_continue.click()
        
        # Esperar inventario
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "inventory_list"))
        )
        
        # Agregar 2 productos
        botones_add = driver.find_elements(By.CSS_SELECTOR, "button.btn_inventory")
        botones_add[0].click()
        botones_add[1].click()
        
        # Verificar badge
        carrito_badge = driver.find_element(By.CLASS_NAME, "shopping_cart_badge")
        assert carrito_badge.text == "2", f"Badge muestra {carrito_badge.text}, deberia ser 2"
        
        # Ir al carrito
        driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()
        
        # Verificar 2 items
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "cart_list"))
        )
        items_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")
        assert len(items_carrito) == 2, f"Hay {len(items_carrito)} items, deberian ser 2"
        
        # Checkout
        driver.find_element(By.ID, "checkout").click()
        
        # Completar formulario
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "first-name"))
        )
        driver.find_element(By.ID, "first-name").send_keys("Juan")
        driver.find_element(By.ID, "last-name").send_keys("Perez")
        driver.find_element(By.ID, "postal-code").send_keys("12345")
        driver.find_element(By.ID, "continue").click()
        
        # Finalizar compra
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.ID, "finish"))
        )
        driver.find_element(By.ID, "finish").click()
        
        # Verificar confirmacion
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "complete-header"))
        )
        mensaje_exito = driver.find_element(By.CLASS_NAME, "complete-header").text
        assert "THANK YOU FOR YOUR ORDER" in mensaje_exito.upper(), \
            f"Se esperaba mensaje de exito, pero se obtuvo: {mensaje_exito}"
        
        # Verificar carrito vacio
        driver.find_element(By.CLASS_NAME, "shopping_cart_link").click()
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CLASS_NAME, "cart_list"))
        )
        items_carrito = driver.find_elements(By.CLASS_NAME, "cart_item")
        assert len(items_carrito) == 0, "El carrito deberia estar vacio despues de la compra"









        