import pytest
from selenium import webdriver


@pytest.fixture(scope="function")
def driver():
    """Fixture para configurar y proporcionar el driver de Selenium a las pruebas."""

    # Configura el driver de Selenium 
    driver = webdriver.Chrome()  
    
    # Espera implícita de 10 segundos
    driver.implicitly_wait(10) 
    
    # Devuelve el driver para que las pruebas puedan usarlo
    yield driver

    # Cierra el navegador después de cada prueba
    driver.quit()  