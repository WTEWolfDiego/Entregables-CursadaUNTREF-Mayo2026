import requests
import pytest

def test_caso_1():

    """Test para verificar la información de la baya en la API de Pokémon."""

    # Realizar una solicitud GET a la API de Pokémon para obtener información 
    response = requests.get("https://pokeapi.co/api/v2/berry/1")
    assert response.status_code == 200
    data = response.json()

    # Verificar que el tamaño de la baya sea 20 y que la sequedad del suelo sea 15
    assert data["size"] == 20, f"Expected size to be 20, but got {data['size']}"
    assert data["soil_dryness"] == 15, f"Expected soil_dryness to be 15, but got {data['soil_dryness']}"
    # Verificar que en firmness, el name sea "soft"
    assert data["firmness"]["name"] == "soft", f"Firmness name debería ser 'soft', pero es {data['firmness']['name']}"
    
    print("Todos los tests pasaron correctamente")
    return data

def test_caso_2():

    """Test para verificar la información de la baya 2 en la API de Pokémon."""

    # Realizar una solicitud GET a la API de Pokémon para obtener información 
    response = requests.get("https://pokeapi.co/api/v2/berry/2")
    assert response.status_code == 200
    data = response.json()

    # Verificar que el tamaño de la baya sea mayor a 20 y que la sequedad del suelo sea 15
    assert data["size"] > 20, f"Expected size to be greater than 20, but got {data['size']}"
    assert data["soil_dryness"] == 15, f"Expected soil_dryness to be 15, but got {data['soil_dryness']}"
    # Verificar que en firmness, el name sea "super-hard"
    assert data["firmness"]["name"] == "super-hard", f"Firmness name debería ser 'super-hard', pero es {data['firmness']['name']}"
    
    print("Todos los tests pasaron correctamente")
    return data

def test_caso_3():

    """Test para verificar la información de Pikachu en la API de Pokémon."""

    # Realizar una solicitud GET a la API de Pokémon para obtener información 
    response = requests.get("https://pokeapi.co/api/v2/pokemon/pikachu/")
    assert response.status_code == 200
    data = response.json()

    # Verificar que la experiencia base de Pikachu sea mayor a 10 y menor a 100
    assert 10 < data["base_experience"] < 1000, f"Expected base_experience to be between 10 and 100, but got {data['base_experience']}"
    # Verificar que en firmness, el type sea "electric"
    tipos = [t["type"]["name"] for t in data["types"]]
    assert "electric" in tipos, f"Se esperaba tipo 'electric', pero los tipos son: {tipos}" 

    print("Todos los tests pasaron correctamente")
    return data



# if __name__ == "__main__":
#     test_caso_1()
#     test_caso_2()
#     test_caso_3()