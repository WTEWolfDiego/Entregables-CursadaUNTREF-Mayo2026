import pytest
import os
import sys
from datetime import datetime

def generate_combined_report():
    """Genera un reporte HTML combinado de todas las pruebas"""
    
    # Obtener la ruta actual del script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Cambiar al directorio del proyecto
    os.chdir(current_dir)
    
    # Crear directorio para reportes
    reports_dir = os.path.join(current_dir, "reports")
    if not os.path.exists(reports_dir):
        os.makedirs(reports_dir)
        print(f"Creado directorio: {reports_dir}")
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    report_file = os.path.join(reports_dir, f"combined_report_{timestamp}.html")
    
    # Verificar que los archivos de prueba existen
    api_test = os.path.join(current_dir, "pokeapi", "test-API-3-b.py")
    ui_test = os.path.join(current_dir, "saucedemo", "test_suit.py")
    
    print(f"Buscando pruebas de API en: {api_test}")
    print(f"Buscando pruebas de UI en: {ui_test}")
    
    if not os.path.exists(api_test):
        print(f"ERROR: No se encuentra {api_test}")
        return 1
    
    if not os.path.exists(ui_test):
        print(f"ERROR: No se encuentra {ui_test}")
        return 1
    
    # Ejecutar todas las pruebas y generar reporte
    print("\nEjecutando pruebas...")
    result = pytest.main([
        api_test,
        ui_test,
        "-v",
        f"--html={report_file}",
        "--self-contained-html"
    ])
    
    print(f"\nReporte generado: {report_file}")
    print(f"Resultado: {'EXITOSO' if result == 0 else 'FALLIDO'}")
    
    return result

if __name__ == "__main__":
    exit_code = generate_combined_report()
    sys.exit(exit_code)