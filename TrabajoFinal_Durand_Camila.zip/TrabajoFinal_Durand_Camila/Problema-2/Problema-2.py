import math

def calcular_discriminante(a, b, c):
    """Función para calcular el discriminante de una ecuación cuadrática."""
    return b**2 - 4*a*c

def resolver_ecuacion_cuadratica(a, b, c):
    """Función para resolver una ecuación cuadrática dada por los coeficientes a, b y c."""
    discriminante = calcular_discriminante(a, b, c)
    
    if discriminante < 0:
        return "La ecuación no tiene soluciones reales."
    elif discriminante == 0:
        x = -b / (2*a)
        return f"La ecuación tiene una solución real: x = {x}"
    else:
        x1 = (-b + math.sqrt(discriminante)) / (2*a)
        x2 = (-b - math.sqrt(discriminante)) / (2*a)
        return f"La ecuación tiene dos soluciones reales: x1 = {x1} y x2 = {x2}"
    
def __main__():
    """Función principal para ejecutar el programa."""
    print("Ecuación cuadrática de la forma ax^2 + bx + c = 0")
    a = float(input("Ingrese el coeficiente a: "))
    b = float(input("Ingrese el coeficiente b: "))
    c = float(input("Ingrese el coeficiente c: "))
    
    resultado = resolver_ecuacion_cuadratica(a, b, c)
    print(resultado)

if __name__ == "__main__":
    __main__()