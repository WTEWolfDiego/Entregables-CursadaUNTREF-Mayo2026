import math

def es_primo(n):
    """Función para determinar si un número es primo."""
    if n <= 1:
        return False
    for i in range(2, int(math.isqrt(n)) + 1):
        if n % i == 0:
            return False
            
    return True

def __main__():
    """Función principal para ejecutar el programa."""
    numero = int(input("Ingrese un número entero: "))
    
    if es_primo(numero):
        print(f"{numero} es un número primo.")
    else:
        print(f"{numero} no es un número primo.")

if __name__ == "__main__":
    __main__()